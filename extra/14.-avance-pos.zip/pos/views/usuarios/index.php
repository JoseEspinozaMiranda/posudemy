<?php include_once 'views/templates/header.php'; ?>

<div class="card">
    <div class="card-header">
        Header
    </div>
    <div class="card-body">
        <h5 class="card-title">Title</h5>
        <p class="card-text">Content</p>
    </div>
</div>

<?php include_once 'views/templates/footer.php'; ?>