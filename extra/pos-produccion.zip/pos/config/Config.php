<?php
define('BASE_URL', 'http://localhost/pos/');
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DBNAME', 'sistema');
define('CHARSET', '');
define('TITLE', 'POS VENTA');
define('MONEDA', 'S/ ');
define('HOST_SMTP', 'smtp.gmail.com');
define('USER_SMTP', 'tucorreo@gmail.com');
define('CLAVE_SMTP', 'clave_generada');
define('PUERTO_SMTP', 465);
?>