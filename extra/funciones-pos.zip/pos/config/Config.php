<?php
define('BASE_URL', 'http://localhost/pos/');
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DBNAME', 'sistema');
define('CHARSET', '');
define('TITLE', 'POS VENTA');
?>